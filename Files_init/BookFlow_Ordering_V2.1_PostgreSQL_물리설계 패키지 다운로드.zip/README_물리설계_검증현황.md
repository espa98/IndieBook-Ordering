# BookFlow Ordering ERD V2.1 → PostgreSQL 물리 설계 / 격리 검증 패키지

상태: **초안 생성 및 정적 검사만 완료 / 격리 DB 실제 실행 미완료 / 운영 배포 보류**.

## 기준 문서
`BookFlow_Ordering_ERD_V2.1_개선본.mmd`, `BookFlow_Ordering_ERD_V2.1_비판적검토_개정서.md`, `Ordering_OPDS_V1.1_승인정책반영본.md`. 실DB `ordering_*` 15개 테이블, 트리거 5개를 읽기 전용 조회하여 대조했다.

## 실행 순서
1. 운영과 분리된 Supabase **별도 프로젝트/별도 PostgreSQL 데이터베이스**를 생성하고 운영 데이터를 비식별 복제한다. 기존 `ordering-dev`는 격리 DB가 아니다.
2. `00_preflight_readonly.sql` 실행. 기존 UNIQUE(tenant_id,id) 인덱스가 있는지 확인하고 원본/복제의 스키마 해시 및 건수를 기록한다.
3. `01_expand_isolated.sql` 실행. 16개 tenant-scoped 신규 테이블과 글로벌 도서 마스터 1개를 추가한다. 신규 테이블은 RLS ON, `anon`/`authenticated` 직접 쓰기 권한 없음. 기존 15개 테이블과 함수는 그대로 둔다.
4. `02_tenant_fks_indexes.sql` 실행. 기존 테이블의 `(tenant_id,id)` UNIQUE가 없다면 **중단**하고 사전 데이터 검증 후 별도 expand 마이그레이션으로 추가한다. 이 파일은 성공 전제 하에 신규 FK와 인덱스를 생성한다.
5. `03_schema_smoke_test.sql` 실행. RLS 및 신규 테이블 존재를 검사한다.
6. 실제 사용자 Owner/Staff JWT, 교차 테넌트, 두 독립 연결 동시 승인/환급, 마지막 1권 동시 배분, 기존 19개 회귀 테스트 수행. 이 패키지에는 자동 병렬 실행기가 포함되지 않았다.
7. 백필/전환/기존 RPC 교체는 별도 검증 및 승인 후 수행한다.

## 설계 경계 및 중요한 미완료 항목
- 이 패키지는 **expand 스키마**다. 기존 `ordering_orders.customer_id`, `ordering_orders.version`, 기존 PO 라인의 `purchase_order_id`, 결제 원장의 `attempt_id`는 아직 추가하지 않는다. 이들은 검증된 backfill 및 기존 RPC 영향 분석이 필요한 **후속 migration**이다.
- `ordering_lot_movements`는 append-only를 목표로 하지만 현 단계에서는 직접 쓰기 권한 회수만 수행했다. 전용 승인 RPC와 원장 트리거가 추가되어야 한다.
- `ordering_order_allocations`의 누적 수량 상한, 버킷 합계, 고객별 인도 상한은 **CHECK만으로 교차 행 검증 불가능**. 후속 RPC에서 동일 주문/로트 잠금과 원장 대사가 필요하다.
- `ordering_payment_attempts`는 증빙 상태 모델만 제공한다. 실제 PG/VAN 확인을 구현하지 않았고 `MANUAL_VERIFIED`는 외부 검증 사실을 의미하지 않는다.
- 결제 원장과 attempt의 연결, 공급처 발주 헤더 연결, 원장과 이동/배분의 1:1 대사는 아직 DB 제약으로 연결되지 않았다.
- 주문 종결 원자적 검증 RPC, Owner 승인 재검증, 직원 권한 정상 경로, 개인정보 보존정책은 후속 단계이다.
- `ordering_books`는 공통 서지 후보로 읽기/쓰기 권한을 모두 회수했다. 별도 서버 측 동기화 경로를 설계해야 한다.
- `SECURITY DEFINER` 공개 함수의 권한, search_path, 인자별 tenant 검사에 대한 추가 감사 필요.
- SQL은 **격리 DB 외 실행 금지**. 운영 배포 승인 전까지 `ordering-dev`에 적용하지 않는다.

## 테스트 증거의 구분
- 수행: 실제 `ordering-dev`의 15개 테이블 컬럼과 5개 트리거 읽기 전용 확인, ERD 문서 대조, SQL 파일 생성.
- 미수행: 격리 DB 접속/DDL 실행, PostgreSQL 엔진 문법·FK 적용, 데이터 백필, JWT 및 병렬 세션 회귀 테스트.
- 따라서 이 설계 패키지를 **검증 통과**로 표시해서는 안 된다.
