-- V2.1 Phase 2. Apply after Phase 1, ONLY to isolated clone.
-- Existing 15 tables are not altered. Tenant-aware references use existing composite UNIQUE.
BEGIN;
ALTER TABLE public.ordering_po_order_allocations
 ADD CONSTRAINT po_alloc_po_fk FOREIGN KEY(tenant_id,po_line_id) REFERENCES public.ordering_supplier_po_lines(tenant_id,id),
 ADD CONSTRAINT po_alloc_line_fk FOREIGN KEY(tenant_id,order_line_id) REFERENCES public.ordering_order_lines(tenant_id,id);
ALTER TABLE public.ordering_supplier_cancel_requests
 ADD CONSTRAINT supplier_cancel_po_fk FOREIGN KEY(tenant_id,po_line_id) REFERENCES public.ordering_supplier_po_lines(tenant_id,id);
ALTER TABLE public.ordering_lot_movements
 ADD CONSTRAINT lot_move_lot_fk FOREIGN KEY(tenant_id,lot_id) REFERENCES public.ordering_receipt_lots(tenant_id,id),
 ADD CONSTRAINT lot_move_line_fk FOREIGN KEY(tenant_id,order_line_id) REFERENCES public.ordering_order_lines(tenant_id,id);
ALTER TABLE public.ordering_order_allocations
 ADD CONSTRAINT order_alloc_line_fk FOREIGN KEY(tenant_id,order_line_id) REFERENCES public.ordering_order_lines(tenant_id,id),
 ADD CONSTRAINT order_alloc_lot_fk FOREIGN KEY(tenant_id,lot_id) REFERENCES public.ordering_receipt_lots(tenant_id,id);
ALTER TABLE public.ordering_handover_lines
 ADD CONSTRAINT handover_line_fk FOREIGN KEY(tenant_id,order_line_id) REFERENCES public.ordering_order_lines(tenant_id,id),
 ADD CONSTRAINT handover_alloc_fk FOREIGN KEY(tenant_id,allocation_id) REFERENCES public.ordering_order_allocations(tenant_id,id);
ALTER TABLE public.ordering_stock_transfers
 ADD CONSTRAINT stock_transfer_lot_fk FOREIGN KEY(tenant_id,lot_id) REFERENCES public.ordering_receipt_lots(tenant_id,id),
 ADD CONSTRAINT stock_transfer_inventory_fk FOREIGN KEY(tenant_id,inventory_entry_id) REFERENCES public.ordering_inventory_ledger(tenant_id,id);
ALTER TABLE public.ordering_supplier_returns
 ADD CONSTRAINT supplier_return_lot_fk FOREIGN KEY(tenant_id,lot_id) REFERENCES public.ordering_receipt_lots(tenant_id,id);
ALTER TABLE public.ordering_order_cancel_requests
 ADD CONSTRAINT cancel_order_line_fk FOREIGN KEY(tenant_id,order_line_id) REFERENCES public.ordering_order_lines(tenant_id,id);
ALTER TABLE public.ordering_notice_attempts
 ADD CONSTRAINT notice_attempt_notice_fk FOREIGN KEY(tenant_id,notice_id) REFERENCES public.ordering_customer_notices(tenant_id,id);
ALTER TABLE public.ordering_payment_attempts
 ADD CONSTRAINT payment_attempt_order_fk FOREIGN KEY(tenant_id,order_id) REFERENCES public.ordering_orders(tenant_id,id);
ALTER TABLE public.ordering_payment_evidence
 ADD CONSTRAINT payment_evidence_attempt_fk FOREIGN KEY(tenant_id,attempt_id) REFERENCES public.ordering_payment_attempts(tenant_id,id);
ALTER TABLE public.ordering_exceptions
 ADD CONSTRAINT exception_order_fk FOREIGN KEY(tenant_id,order_id) REFERENCES public.ordering_orders(tenant_id,id);
ALTER TABLE public.ordering_order_closure_checks
 ADD CONSTRAINT closure_check_order_fk FOREIGN KEY(tenant_id,order_id) REFERENCES public.ordering_orders(tenant_id,id);
CREATE INDEX ON public.ordering_po_order_allocations(tenant_id,order_line_id);
CREATE INDEX ON public.ordering_lot_movements(tenant_id,lot_id,created_at);
CREATE INDEX ON public.ordering_handover_lines(tenant_id,allocation_id);
CREATE INDEX ON public.ordering_payment_attempts(tenant_id,order_id,status);
CREATE INDEX ON public.ordering_exceptions(tenant_id,order_id,status) WHERE blocking;
CREATE INDEX ON public.ordering_outbox(tenant_id,status,next_attempt_at);
COMMIT;
