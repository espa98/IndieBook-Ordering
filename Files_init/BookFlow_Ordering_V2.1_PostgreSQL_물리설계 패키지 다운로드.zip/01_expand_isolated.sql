-- BookFlow Ordering V2.1 EXPAND ONLY. Apply ONLY to an isolated clone.
-- Does not modify existing 15 ordering_* tables, functions, triggers or privileges.
BEGIN;
CREATE TABLE public.ordering_customers (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES public.ordering_tenants(id),
 display_name text NOT NULL CHECK(length(btrim(display_name))>0), created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(tenant_id,id)
);
CREATE TABLE public.ordering_books (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), isbn text, title text NOT NULL, source text NOT NULL DEFAULT 'MANUAL',
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.ordering_purchase_orders (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES public.ordering_tenants(id),
 supplier_code text NOT NULL, status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','SENT','PARTIAL','CLOSED','CANCELLED')),
 version bigint NOT NULL DEFAULT 1 CHECK(version>0), created_at timestamptz NOT NULL DEFAULT now(),UNIQUE(tenant_id,id)
);
CREATE TABLE public.ordering_po_order_allocations (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES public.ordering_tenants(id),
 po_line_id uuid NOT NULL,order_line_id uuid NOT NULL,linked_qty integer NOT NULL CHECK(linked_qty>0),
 created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(tenant_id,id),
 UNIQUE(tenant_id,po_line_id,order_line_id)
);
CREATE TABLE public.ordering_supplier_cancel_requests (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES public.ordering_tenants(id),
 po_line_id uuid NOT NULL,requested_qty integer NOT NULL CHECK(requested_qty>0),
 accepted_qty integer NOT NULL DEFAULT 0 CHECK(accepted_qty>=0 AND accepted_qty<=requested_qty),
 status text NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','ACCEPTED','PARTIAL','REJECTED')),
 created_at timestamptz NOT NULL DEFAULT now(),UNIQUE(tenant_id,id)
);
CREATE TABLE public.ordering_lot_movements (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES public.ordering_tenants(id),
 lot_id uuid NOT NULL,order_line_id uuid,from_bucket text,to_bucket text,qty integer NOT NULL CHECK(qty>0),
 kind text NOT NULL DEFAULT 'TRANSFER' CHECK(kind IN ('TRANSFER','MIGRATION_OPENING')),
 command_key text NOT NULL,actor_user_id uuid,created_at timestamptz NOT NULL DEFAULT now(),
 CHECK((kind='MIGRATION_OPENING' AND from_bucket IS NULL AND to_bucket IS NOT NULL)
 OR (kind='TRANSFER' AND from_bucket IS NOT NULL AND to_bucket IS NOT NULL AND from_bucket<>to_bucket)),
 UNIQUE(tenant_id,id),UNIQUE(tenant_id,command_key)
);
CREATE TABLE public.ordering_order_allocations (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES public.ordering_tenants(id),
 order_line_id uuid NOT NULL,lot_id uuid NOT NULL,allocated_qty integer NOT NULL DEFAULT 0 CHECK(allocated_qty>=0),
 released_qty integer NOT NULL DEFAULT 0 CHECK(released_qty>=0),
 delivered_qty integer NOT NULL DEFAULT 0 CHECK(delivered_qty>=0),
 CHECK(released_qty+delivered_qty<=allocated_qty),UNIQUE(tenant_id,id),UNIQUE(tenant_id,order_line_id,lot_id)
);
CREATE TABLE public.ordering_handover_lines (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES public.ordering_tenants(id),
 order_line_id uuid NOT NULL,allocation_id uuid NOT NULL,qty integer NOT NULL CHECK(qty>0),
 allocated_amount_krw bigint NOT NULL CHECK(allocated_amount_krw>=0),command_key text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(),UNIQUE(tenant_id,id),UNIQUE(tenant_id,command_key)
);
CREATE TABLE public.ordering_stock_transfers (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES public.ordering_tenants(id),
 lot_id uuid NOT NULL,inventory_entry_id uuid NOT NULL,qty integer NOT NULL CHECK(qty>0),
 created_at timestamptz NOT NULL DEFAULT now(),UNIQUE(tenant_id,id),UNIQUE(tenant_id,inventory_entry_id)
);
CREATE TABLE public.ordering_supplier_returns (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES public.ordering_tenants(id),
 lot_id uuid NOT NULL,dispatched_qty integer NOT NULL DEFAULT 0 CHECK(dispatched_qty>=0),
 completed_qty integer NOT NULL DEFAULT 0 CHECK(completed_qty>=0 AND completed_qty<=dispatched_qty),
 status text NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','DISPATCHED','COMPLETED','REJECTED')),
 UNIQUE(tenant_id,id)
);
CREATE TABLE public.ordering_order_cancel_requests (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES public.ordering_tenants(id),
 order_line_id uuid NOT NULL,requested_qty integer NOT NULL CHECK(requested_qty>0),
 status text NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','APPROVED','REJECTED','CANCELLED')),
 created_at timestamptz NOT NULL DEFAULT now(),UNIQUE(tenant_id,id)
);
CREATE TABLE public.ordering_notice_attempts (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES public.ordering_tenants(id),
 notice_id uuid NOT NULL,attempt_status text NOT NULL CHECK(attempt_status IN ('PENDING','SENT','FAILED','CONFIRMED')),
 provider_reference text,created_at timestamptz NOT NULL DEFAULT now(),UNIQUE(tenant_id,id)
);
CREATE TABLE public.ordering_payment_attempts (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES public.ordering_tenants(id),
 order_id uuid NOT NULL,amount_krw bigint NOT NULL CHECK(amount_krw>0),
 method text NOT NULL CHECK(method IN ('CARD','EASY_PAY','BANK_TRANSFER')),
 external_reference text NOT NULL CHECK(length(btrim(external_reference))>0),
 status text NOT NULL DEFAULT 'REPORTED' CHECK(status IN ('REPORTED','MANUAL_VERIFIED','PROVIDER_VERIFIED','REJECTED')),
 verification_source text,verified_by uuid,verified_at timestamptz,created_at timestamptz NOT NULL DEFAULT now(),
 CHECK((status IN ('MANUAL_VERIFIED','PROVIDER_VERIFIED') AND verification_source IS NOT NULL AND verified_by IS NOT NULL AND verified_at IS NOT NULL)
 OR status IN ('REPORTED','REJECTED')),
 UNIQUE(tenant_id,id),UNIQUE(tenant_id,method,external_reference)
);
CREATE TABLE public.ordering_payment_evidence (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES public.ordering_tenants(id),
 attempt_id uuid NOT NULL,verification_result text NOT NULL CHECK(verification_result IN ('PENDING','MATCHED','MISMATCH','UNVERIFIABLE')),
 evidence_digest text,reference_uri text,created_at timestamptz NOT NULL DEFAULT now(),UNIQUE(tenant_id,id)
);
CREATE TABLE public.ordering_exceptions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES public.ordering_tenants(id),
 order_id uuid NOT NULL,kind text NOT NULL,blocking boolean NOT NULL DEFAULT true,
 status text NOT NULL DEFAULT 'OPEN' CHECK(status IN ('OPEN','RESOLVED','WAIVED')),
 resolution_reason text,resolved_by uuid,resolved_at timestamptz,
 CHECK(status='OPEN' OR (resolution_reason IS NOT NULL AND resolved_by IS NOT NULL AND resolved_at IS NOT NULL)),
 created_at timestamptz NOT NULL DEFAULT now(),UNIQUE(tenant_id,id)
);
CREATE TABLE public.ordering_order_closure_checks (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES public.ordering_tenants(id),
 order_id uuid NOT NULL,checked_version bigint NOT NULL CHECK(checked_version>=0),
 result boolean NOT NULL,details jsonb NOT NULL DEFAULT '{}'::jsonb,
 checked_at timestamptz NOT NULL DEFAULT now(),UNIQUE(tenant_id,id)
);
CREATE TABLE public.ordering_outbox (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES public.ordering_tenants(id),
 event_type text NOT NULL,payload jsonb NOT NULL DEFAULT '{}'::jsonb,
 status text NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','PROCESSING','SENT','FAILED')),
 attempts integer NOT NULL DEFAULT 0 CHECK(attempts>=0),next_attempt_at timestamptz NOT NULL DEFAULT now(),
 created_at timestamptz NOT NULL DEFAULT now(),UNIQUE(tenant_id,id)
);
-- FK safety: tenant-aware references to legacy tables require verified UNIQUE(tenant_id,id).
-- Those constraints are created only in a separate validated migration.
DO $$
DECLARE t text;
BEGIN
 FOR t IN SELECT unnest(ARRAY[
 'ordering_customers','ordering_purchase_orders','ordering_po_order_allocations',
 'ordering_supplier_cancel_requests','ordering_lot_movements','ordering_order_allocations',
 'ordering_handover_lines','ordering_stock_transfers','ordering_supplier_returns',
 'ordering_order_cancel_requests','ordering_notice_attempts','ordering_payment_attempts',
 'ordering_payment_evidence','ordering_exceptions','ordering_order_closure_checks','ordering_outbox'
 ]) LOOP
 EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY',t);
 EXECUTE format('REVOKE ALL ON public.%I FROM PUBLIC,anon,authenticated',t);
 EXECUTE format('CREATE POLICY tenant_member_read ON public.%I FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM public.ordering_members m WHERE m.tenant_id=%I.tenant_id AND m.user_id=(select auth.uid()) AND m.active))',t,t);
 END LOOP;
END $$;
REVOKE ALL ON public.ordering_books FROM PUBLIC,anon,authenticated;
ALTER TABLE public.ordering_books ENABLE ROW LEVEL SECURITY;
COMMIT;
