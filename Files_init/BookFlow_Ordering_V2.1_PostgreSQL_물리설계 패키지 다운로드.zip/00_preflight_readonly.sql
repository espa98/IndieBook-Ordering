-- Read-only preflight. Run on source and isolated clone.
SELECT current_database() db, current_user db_role, version();
SELECT table_name, count(*) columns FROM information_schema.columns
WHERE table_schema='public' AND table_name LIKE 'ordering_%' GROUP BY table_name ORDER BY 1;
SELECT conrelid::regclass::text table_name, conname, contype,pg_get_constraintdef(oid) definition
FROM pg_constraint WHERE connamespace='public'::regnamespace
AND conrelid::regclass::text LIKE 'ordering_%' ORDER BY 1,2;
SELECT c.relname table_name,t.tgname trigger_name,p.proname function_name
FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_proc p ON p.oid=t.tgfoid
WHERE c.relnamespace='public'::regnamespace AND c.relname LIKE 'ordering_%' AND NOT t.tgisinternal;
SELECT n.nspname, p.proname, p.prosecdef,
has_function_privilege('anon',p.oid,'EXECUTE') anon_execute,
has_function_privilege('authenticated',p.oid,'EXECUTE') authenticated_execute
FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
WHERE n.nspname='public' AND p.proname LIKE 'ordering_%';
SELECT schemaname,tablename,policyname,cmd,roles,qual,with_check
FROM pg_policies WHERE schemaname='public' AND tablename LIKE 'ordering_%';
-- Preflight composite FK eligibility: inspect UNIQUE(tenant_id,id) on every referenced legacy table.
SELECT c.relname table_name, i.relname index_name,pg_get_indexdef(i.oid) index_definition
FROM pg_index x JOIN pg_class c ON c.oid=x.indrelid JOIN pg_class i ON i.oid=x.indexrelid
WHERE c.relnamespace='public'::regnamespace AND c.relname LIKE 'ordering_%'
AND x.indisunique ORDER BY 1,2;
