-- Execute ONLY in isolated clone AFTER migrations 01 and 02.
BEGIN;
DO $$
DECLARE n integer;
BEGIN
 SELECT count(*) INTO n FROM information_schema.tables
 WHERE table_schema='public' AND table_name IN
 ('ordering_customers','ordering_purchase_orders','ordering_po_order_allocations',
  'ordering_supplier_cancel_requests','ordering_lot_movements','ordering_order_allocations',
  'ordering_handover_lines','ordering_stock_transfers','ordering_supplier_returns',
  'ordering_order_cancel_requests','ordering_notice_attempts','ordering_payment_attempts',
  'ordering_payment_evidence','ordering_exceptions','ordering_order_closure_checks','ordering_outbox');
 IF n<>16 THEN RAISE EXCEPTION 'EXPECTED_16_NEW_TENANT_TABLES_GOT_%',n; END IF;
 IF EXISTS(SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
 WHERE n.nspname='public' AND c.relname IN ('ordering_customers','ordering_purchase_orders',
 'ordering_po_order_allocations','ordering_supplier_cancel_requests','ordering_lot_movements',
 'ordering_order_allocations','ordering_handover_lines','ordering_stock_transfers',
 'ordering_supplier_returns','ordering_order_cancel_requests','ordering_notice_attempts',
 'ordering_payment_attempts','ordering_payment_evidence','ordering_exceptions',
 'ordering_order_closure_checks','ordering_outbox') AND NOT c.relrowsecurity)
 THEN RAISE EXCEPTION 'RLS_NOT_ENABLED'; END IF;
END $$;
ROLLBACK;
-- Separate test sessions required for parallel idempotency and last-copy allocation.
-- Existing 19 JWT tests must be rerun with actual users. This script does NOT claim those tests.
